from flask import render_template,redirect,session,request, flash
from flask_app import app
from flask_app.models.tavern import Tavern
from flask_app.models.user import User


@app.route('/new/tavern')
def new_tavern():
    if 'user_id' not in session:
        return redirect('/logout')
    data = {
        "id":session['user_id']
    }
    return render_template('new_tavern.html', user=User.get_by_id(data))


@app.route('/create/tavern',methods=['POST'])
def create_tavern():
    if 'user_id' not in session:
        return redirect('/logout')
    data = {
        "name": request.form["name"],
        "race": request.form["race"],
        "class": request.form["class"],
        "background": request.form["background"],
        "users_id": session["user_id"]
    }
    Tavern.save(data)
    return redirect('/dashboard')

@app.route('/user/taverns',methods=['GET'])
def get_taverns():
    if 'user_id' not in session:
        return redirect('/logout')
    data = {
        "id":id
    }
    user_data = {
        "id":session['user_id']
    }
    return render_template("user_taverns.html",tavern =Tavern.get_all(), user=User.get_by_id(user_data))


@app.route('/edit/tavern/<int:id>')
def edit_tavern(id):
    if 'user_id' not in session:
        return redirect('/logout')
    data = {
        "id":id
    }
    user_data = {
        "id":session['user_id']
    }
    return render_template("edit_tavern.html",edit =Tavern.get_one(data), user=User.get_by_id(user_data))


@app.route('/update/tavern/', methods=['POST'])
def update_tavern():
    if 'user_id' not in session:
        return redirect('/logout')
    data = {
        "name": request.form["name"],
        "race": request.form["race"],
        "class": request.form["class"],
        "background": request.form["background"],
        "id": request.form['id']
    }
    Tavern.update(data)
    return redirect('/dashboard')

@app.route('/tavern/<int:id>')
def show_tavern(id):
    if 'user_id' not in session:
        return redirect('/logout')
    data = {
        "id":id
    }
    user_data = {
        "id":session['user_id']
    }
    return render_template("show_tavern.html", tavern=Tavern.get_one(data),user=User.get_by_id(user_data))

@app.route('/lookingforgroup/tavern/', methods=['GET'])
def lfg_tavern():
    if 'user_id' not in session:
        return redirect('/logout')
    data = {
        "id":id
    }
    user_data = {
        "id":session['user_id']
    }
    return render_template("looking_for_group.html", tavern=Tavern.get_all(),user=User.get_by_id(user_data))

@app.route('/destroy/tavern/<int:id>')
def destroy_tavern(id):
    if 'user_id' not in session:
        return redirect('/logout')
    data = {
        "id":id
    }
    Tavern.destroy(data)
    return redirect('/dashboard')