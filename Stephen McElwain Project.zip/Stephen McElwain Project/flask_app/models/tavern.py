from flask_app.config.mysqlconnection import connectToMySQL
from flask import flash

class Tavern:
    db_name = 'taverns'
    def __init__(self,db_data):
        self.id = db_data['id']
        self.name = db_data['name']
        self.race = db_data['race']
        self.type = db_data['class']
        self.background = db_data['background']
        self.created_at = db_data['created_at']
        self.updated_at = db_data['updated_at']
        self.user_id = db_data['user_id']
        self.first_name = db_data['first_name']
        self.last_name = db_data['last_name']
        

    @classmethod
    def save(cls,data):
        query = "INSERT INTO taverns (name, race, class, background, user_id) VALUES (%(name)s, %(race)s, %(class)s, %(background)s, %(users_id)s);"
        return connectToMySQL(cls.db_name).query_db(query, data)

    @classmethod
    def get_all(cls):
        query = "SELECT * FROM taverns JOIN users ON taverns.user_id = users.id;"
        results =  connectToMySQL(cls.db_name).query_db(query)
        print(results)
        all_taverns = []
        if results: 
            for row in results:
                all_taverns.append(cls(row))
        return all_taverns
    
    @classmethod
    def get_one(cls,data):
        query = "SELECT * FROM taverns JOIN users ON taverns.user_id = users.id WHERE taverns.id = %(id)s;"
        results = connectToMySQL(cls.db_name).query_db(query,data)
        return cls( results[0] )

    @classmethod
    def update(cls, data):
        query = "UPDATE taverns SET name=%(name)s, race=%(race)s, class=%(class)s, background=%(background)s, updated_at=NOW() WHERE id = %(id)s;"
        return connectToMySQL(cls.db_name).query_db(query,data)
    
    @classmethod
    def destroy(cls,data):
        query = "DELETE FROM taverns WHERE id = %(id)s;"
        return connectToMySQL(cls.db_name).query_db(query,data)

    @staticmethod
    def validate_tavern(tavern):
        is_valid = True
        if len(tavern['name']) < 2:
            is_valid = False
            flash(" must be at least 2 characters long","tavern")
        if len(tavern['race']) < 2:
            is_valid = False
            flash(" must be at least 2 characters long","tavern")
        if len(tavern['class']) < 2:
            is_valid = False
            flash(" must be at least 2 characters long","tavern")
        if len(tavern['background']) < 1:
            is_valid = False
            flash(" must be at least 1 characters long","tavern")
        return is_valid
        